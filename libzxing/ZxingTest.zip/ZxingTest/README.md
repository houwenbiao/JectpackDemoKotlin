# ZxingTest

博客链接
> https://blog.csdn.net/lowprofile_coding/article/details/83386050

![image](https://github.com/ansen666/images/blob/master/zxing/zxing.gif?raw=true)


